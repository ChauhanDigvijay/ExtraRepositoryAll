//
//  ViewController.swift
//  FrameworkDemo
//
//  Created by Puneet  on 7/27/17.
//  Copyright © 2017 Puneet . All rights reserved.
//

import UIKit
import FishBowlLibrary



class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        AppConstant.sharedInstance.AppPointingURL(PointingServer: "https://stg-cornerbakerycafe.fishbowlcloud.com/clpapi/")
        AppConstant.sharedInstance.AppPointingClientID(clientId: "201969E1BFD242E189FE7B6297B1B517")
        AppConstant.sharedInstance.AppPointingClientSecret(clientSecret: "C65A0DC0F28C469FB7376F972DEFBC17")
        AppConstant.sharedInstance.AppPointingTanentID(tanentId: "10051")
        AppConstant.sharedInstance.AppPointingSpendgoBaseUrl(spendgoBaseUrl: "m.spendgo.com") // Example URL Please provide correct Details according to correct data
        
        //Example how you need to call the DataManager class.
        
        let objDataManager = DataManager()  // Intializing the DataManager Class

        let tempDict = NSMutableDictionary()  // Creating Body as it's a POST Method
        
        let userName : String = "puneetkathuria@yahoo.com"
        let password : String = "password"
        
        tempDict.setValue(userName, forKey : "username")
        tempDict.setValue(password, forKey : "password")
        
       // If Method is GET then no need to create Body. You can pass nil in the dictBody. For POST and PUT method you need to pass correct body as provided on Readme Doc. 
        
        // for any Doubt please refer --  https://fishbowl-doc.readme.io/v1.0/reference#swift-sdk-integration
        
    //    All the method defination, declaration and SDK Integration is properly Documented there.
        
        
        print("tempDict is \(tempDict)")
        objDataManager.loginAPI(dictBody: tempDict as [NSObject : AnyObject])
        { (response, error) in
            
            if error != nil
            {
                let dicResponse : Dictionary = response as! [String:AnyObject]
                let strMessage : String = dicResponse["message"]! as! String
                if(error == DataManagerError.BadRequest)
                {
                    print("error is \(strMessage)")
                }
                else if(error == DataManagerError.TokenExpiration)
                {
                    print("error is \(strMessage)")
                    // Get the Token again and call the same api.
                }
                else if(error == DataManagerError.InternalServerError)
                {
                    print("error is \(strMessage)")
                    // There is some problem from server end response.
                }
                else if(error == DataManagerError.ServerUnavailable)
                {
                    print("error is \(strMessage)")
                    // Server is tempararly Unavailable.
                }
                else if(error == DataManagerError.Unknown)
                {
                    print("error is \(strMessage)")
                    // unknown error.
                }
                
            }
            else
            {
                print(response!)
            }
            
        }
        
      
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

