//
//  FishBowlLibrary.h
//  FishBowlLibrary
//
//  Created by Puneet  on 17/07/17.
//  Copyright © 2017 Fishbowl. All rights reserved.

#import <UIKit/UIKit.h>


//! Project version number for FishBowlLibrary.
FOUNDATION_EXPORT double FishBowlLibraryVersionNumber;

//! Project version string for FishBowlLibrary.
FOUNDATION_EXPORT const unsigned char FishBowlLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FishBowlLibrary/PublicHeader.h>


