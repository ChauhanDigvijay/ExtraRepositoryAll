package iammert.com.dagger_android_injection.data;

import javax.inject.Inject;

/**
 * Created by mertsimsek on 26/05/2017.
 */

public class ApiService {

    @Inject
    public ApiService() {
    }

    public void loadData(){

    }
}
