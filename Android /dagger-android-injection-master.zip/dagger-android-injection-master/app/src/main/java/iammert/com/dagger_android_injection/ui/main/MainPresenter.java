package iammert.com.dagger_android_injection.ui.main;

/**
 * Created by mertsimsek on 25/05/2017.
 */

public interface MainPresenter {
    void loadMain();
}
