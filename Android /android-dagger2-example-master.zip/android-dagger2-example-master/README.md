# android-dagger2-example
This project implements the dagger 2 in android for dependency injection

The complete explanation is present in the following articles:
- [Part 1](https://blog.mindorks.com/introduction-to-dagger-2-using-dependency-injection-in-android-part-1-223289c2a01b)
- [Part 2](https://blog.mindorks.com/introduction-to-dagger-2-using-dependency-injection-in-android-part-2-b55857911bcd)

### [Check out Mindorks awesome open source projects here](https://mindorks.com/open-source-projects)
